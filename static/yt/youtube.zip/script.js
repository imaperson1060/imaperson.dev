chrome.contextMenus.create({
  id: "ytLink",
  title: "Watch Ad-Free",
  contexts: [
    "link"
  ],
  "targetUrlPatterns": [
    "*://*.youtube.com/watch?v=*",
    "*://youtu.be/*"
  ]
});

function getId(url) {
  var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
  var match = url.match(regExp);
  return (match && match[7].length == 11) ? match[7] : false;
}

function contextClick(info, tab) {
  const id = getId(info.linkUrl);
  chrome.tabs.update(tab.id, {
    url: new Date().getMonth() + "/" + new Date().getDate() == "4/1" ? "https://api.imaperson.dev/yt/watch/dQw4w9WgXcQ" : `https://api.imaperson.dev/yt/watch/${id}`
  });
}

chrome.contextMenus.onClicked.addListener(contextClick)