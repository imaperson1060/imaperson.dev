chrome.contextMenus.create({
  id: "ytLink",
  title: "Watch Ad-Free",
  contexts: [
    "link"
  ],
  "targetUrlPatterns": [
    "*://*.youtube.com/watch?v=*",
    "*://youtu.be/*"
  ]
});

function getParameterByName(url, name) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

function contextClick(info, tab) {
  const id = getParameterByName(info.linkUrl, "v");
  chrome.tabs.update(tab.id, {
    url: new Date().getMonth() + "/" + new Date().getDate() == "4/1" ? "https://api.imaperson.dev/yt/watch/dQw4w9WgXcQ" : `https://api.imaperson.dev/yt/watch/${id}`
  });
}

chrome.contextMenus.onClicked.addListener(contextClick)